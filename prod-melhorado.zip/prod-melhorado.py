import sqlite3
from tkinter import *
from tkinter import ttk, messagebox
from datetime import datetime

# --- 1. Configuração e Funções do Banco de Dados SQLite ---
DB_NAME = 'estoque_barbearia.db'

def setup_db():
    """Cria a tabela de produtos se ela não existir."""
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS produtos (
            id INTEGER PRIMARY KEY,
            nome TEXT NOT NULL,
            categoria TEXT NOT NULL,
            quantidade REAL NOT NULL,
            minimo INTEGER NOT NULL,
            preco_custo REAL DEFAULT 0,
            preco_venda REAL DEFAULT 0
        )
    ''')
    # Tenta adicionar colunas se a tabela já existir sem elas
    try:
        cursor.execute("ALTER TABLE produtos ADD COLUMN preco_custo REAL DEFAULT 0")
    except sqlite3.OperationalError:
        pass
    try:
        cursor.execute("ALTER TABLE produtos ADD COLUMN preco_venda REAL DEFAULT 0")
    except sqlite3.OperationalError:
        pass

    # Cria tabela de movimentações
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS movimentacoes (
            id INTEGER PRIMARY KEY,
            produto_id INTEGER NOT NULL,
            tipo TEXT NOT NULL,
            quantidade REAL NOT NULL,
            preco_unitario REAL NOT NULL,
            data_hora TEXT NOT NULL,
            FOREIGN KEY (produto_id) REFERENCES produtos (id)
        )
    ''')
    conn.commit()
    conn.close()

def execute_query(query, params=()):
    """Função genérica para executar comandos SQL."""
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute(query, params)
    conn.commit()
    conn.close()

# --- 2. Funções de Manipulação de Estoque ---

def adicionar_produto(nome, categoria, quantidade, minimo):
    """Cadastra um novo produto."""
    try:
        quantidade = float(quantidade)
        minimo = int(minimo)
        execute_query(
            "INSERT INTO produtos (nome, categoria, quantidade, minimo, preco_custo, preco_venda) VALUES (?, ?, ?, ?, 0, 0)",
            (nome, categoria, quantidade, minimo)
        )
        messagebox.showinfo("Sucesso", f"Produto '{nome}' cadastrado com sucesso!")
        atualizar_listagem()
    except ValueError:
        messagebox.showerror("Erro de Entrada", "Quantidade e Estoque Mínimo devem ser números válidos.")

def atualizar_estoque(produto_id, delta, tipo_mov=None, preco_unit=None):
    """Aumenta ou diminui a quantidade de um produto."""
    try:
        delta = float(delta)
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        cursor.execute("SELECT quantidade, nome, preco_custo, preco_venda FROM produtos WHERE id=?", (produto_id,))
        resultado = cursor.fetchone()
        quantidade_atual = resultado[0]
        nome_produto = resultado[1]
        preco_custo_atual = resultado[2]
        preco_venda_atual = resultado[3]
        conn.close()

        nova_quantidade = quantidade_atual + delta

        if nova_quantidade < 0:
            messagebox.showwarning("Atenção", "Operação cancelada: A quantidade não pode ser negativa!")
            return

        execute_query(
            "UPDATE produtos SET quantidade = ? WHERE id = ?",
            (nova_quantidade, produto_id)
        )

        messagebox.showinfo("Sucesso", f"Estoque atualizado. Nova quantidade: {nova_quantidade}")

        if nova_quantidade < 3:
            messagebox.showwarning("⚠️ ATENÇÃO - Estoque Baixo!",
                                f"O produto {nome_produto} está com estoque baixo!\n"
                                f"Quantidade atual: {nova_quantidade}\n"
                                f"Recomenda-se repor o estoque.")

        # registra movimentação se tipo informado
        if tipo_mov:
            if preco_unit is None or str(preco_unit).strip() == "":
                preco_unit = preco_custo_atual if tipo_mov == "ENTRADA" else preco_venda_atual
            try:
                preco_unit = float(preco_unit)
            except:
                preco_unit = preco_custo_atual if tipo_mov == "ENTRADA" else preco_venda_atual

            agora = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            tipo_norm = "ENTRADA" if tipo_mov == "ENTRADA" else "SAIDA"
            execute_query(
                "INSERT INTO movimentacoes (produto_id, tipo, quantidade, preco_unitario, data_hora) VALUES (?, ?, ?, ?, ?)",
                (produto_id, tipo_norm, abs(delta), preco_unit, agora)
            )

        atualizar_listagem()

    except Exception as e:
        messagebox.showerror("Erro", f"Ocorreu um erro ao atualizar o estoque: {e}")

# --- 3. Funções da Interface Gráfica (Tkinter) ---

def atualizar_listagem():
    """Limpa e preenche a Treeview com os dados atualizados do banco."""
    for i in tree.get_children():
        tree.delete(i)

    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute("SELECT id, nome, categoria, quantidade, minimo, preco_custo, preco_venda FROM produtos ORDER BY categoria, nome")
    registros = cursor.fetchall()
    conn.close()

    for idx, registro in enumerate(registros):
        (id, nome, categoria, quantidade, minimo, preco_custo, preco_venda) = registro
        tags = []
        if quantidade < 3:
            tags.append('alerta')
        tags.append('odd' if idx % 2 == 1 else 'even')
        tree.insert('', 'end', values=(id, nome, categoria, quantidade, minimo, preco_custo, preco_venda), tags=tuple(tags))

def abrir_janela_cadastro():
    """Abre a janela para cadastrar um novo produto."""
    janela_c = Toplevel(root)
    janela_c.title("Cadastrar Produto")
    janela_c.geometry("300x250")
    janela_c.configure(bg='#B6B6B6')

    Label(janela_c, text="Nome:", bg='#B6B6B6').pack(pady=5)
    nome_e = Entry(janela_c)
    nome_e.pack()

    Label(janela_c, text="Categoria:", bg='#B6B6B6').pack(pady=5)
    categoria_e = ttk.Combobox(janela_c, values=["Pomada", "Shampoo", "Frigobar", "Outro Insumo"], state="readonly")
    categoria_e.pack()
    categoria_e.current(0)

    Label(janela_c, text="Qtd. Inicial:", bg='#B6B6B6').pack(pady=5)
    qtd_e = Entry(janela_c)
    qtd_e.insert(0, "0")
    qtd_e.pack()

    Label(janela_c, text="Qtd. Mínima:", bg='#B6B6B6').pack(pady=5)
    min_e = Entry(janela_c)
    min_e.insert(0, "0")
    min_e.pack()

    Button(janela_c, text="Cadastrar", bg="#BBD4F2", fg="black",
           command=lambda: adicionar_produto(nome_e.get(), categoria_e.get(), qtd_e.get(), min_e.get())).pack(pady=10)

def abrir_janela_precos():
    """Abre janela para definir preço de custo e venda do produto selecionado."""
    if not tree.selection():
        messagebox.showwarning("Atenção", "Selecione um produto na lista primeiro.")
        return

    item = tree.item(tree.focus())
    produto_id = item['values'][0]
    nome_produto = item['values'][1]
    preco_custo_atual = item['values'][5] if len(item['values']) > 5 else 0
    preco_venda_atual = item['values'][6] if len(item['values']) > 6 else 0

    janela_p = Toplevel(root)
    janela_p.title(f"Definir Preços: {nome_produto}")
    janela_p.geometry("300x220")
    janela_p.configure(bg='#B6B6B6')

    Label(janela_p, text=f"Produto: {nome_produto}", bg='#B6B6B6').pack(pady=10)
    Label(janela_p, text="Preço de Custo (R$):", bg='#B6B6B6').pack(pady=5)
    e_custo = Entry(janela_p)
    e_custo.insert(0, str(preco_custo_atual))
    e_custo.pack()
    Label(janela_p, text="Preço de Venda (R$):", bg='#B6B6B6').pack(pady=5)
    e_venda = Entry(janela_p)
    e_venda.insert(0, str(preco_venda_atual))
    e_venda.pack()

    def salvar():
        try:
            custo = float(e_custo.get())
            venda = float(e_venda.get())
            execute_query("UPDATE produtos SET preco_custo=?, preco_venda=? WHERE id=?", (custo, venda, produto_id))
            messagebox.showinfo("Sucesso", "Preços atualizados!")
            atualizar_listagem()
            janela_p.destroy()
        except:
            messagebox.showerror("Erro", "Valores inválidos de preço.")

    Button(janela_p, text="Salvar", bg="#BBD4F2", fg="black", command=salvar).pack(pady=10)

def abrir_janela_movimentacao(tipo):
    """Abre a janela para Entrada ou Saída de estoque."""
    if not tree.selection():
        messagebox.showwarning("Atenção", "Selecione um produto na lista primeiro.")
        return

    item_selecionado = tree.item(tree.focus())
    produto_id = item_selecionado['values'][0]
    nome_produto = item_selecionado['values'][1]

    janela_m = Toplevel(root)
    janela_m.title(f"{tipo} de Estoque: {nome_produto}")
    janela_m.geometry("300x200")
    janela_m.configure(bg='#B6B6B6')

    delta_sinal = 1 if tipo == "ENTRADA" else -1

    Label(janela_m, text=f"Produto: {nome_produto}", bg='#B6B6B6').pack(pady=10)
    Label(janela_m, text=f"Quantidade para {tipo}:", bg='#B6B6B6').pack(pady=5)

    qtd_m = Entry(janela_m)
    qtd_m.insert(0, "1")
    qtd_m.pack()

    Label(janela_m, text="Preço unitário (opcional):", bg='#B6B6B6').pack(pady=5)
    preco_e = Entry(janela_m)
    preco_e.pack()

    Button(janela_m, text=tipo, bg="#BBD4F2", fg="black",
           command=lambda: [
               atualizar_estoque(
                   produto_id,
                   float(qtd_m.get()) * delta_sinal,
                   tipo_mov=("ENTRADA" if tipo == "ENTRADA" else "SAIDA"),
                   preco_unit=preco_e.get()
               ),
               janela_m.destroy()
           ]).pack(pady=10)

def calcular_resumo_caixa(periodo_inicio=None, periodo_fim=None, produto_id=None):
    """Retorna lista com (produto_id, nome, qtd_entrada, qtd_saida, total_compra, total_venda).
    Se produto_id for informado, retorna apenas para esse produto.
    """
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    params = []
    filtro_data = ""
    filtro_prod = ""
    if produto_id:
        filtro_prod = " WHERE p.id = ?"
        params.append(produto_id)
    if periodo_inicio and periodo_fim:
        filtro_data = " AND datetime(data_hora) BETWEEN datetime(?) AND datetime(?)"
        params.extend([periodo_inicio + " 00:00:00", periodo_fim + " 23:59:59"])

    cursor.execute(
        f"""
        SELECT p.id, p.nome,
               SUM(CASE WHEN m.tipo='ENTRADA' THEN m.quantidade ELSE 0 END) AS qtd_entrada,
               SUM(CASE WHEN m.tipo='SAIDA' THEN m.quantidade ELSE 0 END) AS qtd_saida,
               SUM(CASE WHEN m.tipo='ENTRADA' THEN m.quantidade*m.preco_unitario ELSE 0 END) AS total_compra,
               SUM(CASE WHEN m.tipo='SAIDA' THEN m.quantidade*m.preco_unitario ELSE 0 END) AS total_venda
        FROM produtos p
        {filtro_prod}
        LEFT JOIN movimentacoes m ON m.produto_id = p.id {filtro_data}
        GROUP BY p.id, p.nome
        ORDER BY p.nome
        """,
        params
    )
    dados = cursor.fetchall()
    conn.close()
    return dados

def abrir_janela_fechamento_caixa():
    janela_f = Toplevel(root)
    janela_f.title("Fechamento de Caixa")
    janela_f.geometry("900x500")
    janela_f.configure(bg='#B6B6B6')

    frame_filtros = Frame(janela_f, bg='#B6B6B6')
    frame_filtros.pack(pady=5)

    # Combobox de produto (pré-seleciona o produto atual da tabela, se houver)
    Label(frame_filtros, text="Produto:", bg='#B6B6B6').pack(side=LEFT, padx=(5,2))
    produtos_lista = []
    conn = sqlite3.connect(DB_NAME)
    cur = conn.cursor()
    cur.execute("SELECT id, nome FROM produtos ORDER BY nome")
    for pid, pnome in cur.fetchall():
        produtos_lista.append(f"{pid} - {pnome}")
    conn.close()
    cb_produto = ttk.Combobox(frame_filtros, values=produtos_lista, width=30, state='readonly')
    cb_produto.pack(side=LEFT, padx=(0,10))
    # tenta pré-selecionar
    try:
        sel = tree.item(tree.focus())
        if sel and sel.get('values'):
            pid_sel = sel['values'][0]
            for i, s in enumerate(produtos_lista):
                if s.startswith(f"{pid_sel} - "):
                    cb_produto.current(i)
                    break
    except:
        pass

    Label(frame_filtros, text="Início (AAAA-MM-DD):", bg='#B6B6B6').pack(side=LEFT, padx=5)
    e_ini = Entry(frame_filtros, width=12)
    e_ini.pack(side=LEFT)
    Label(frame_filtros, text="Fim (AAAA-MM-DD):", bg='#B6B6B6').pack(side=LEFT, padx=5)
    e_fim = Entry(frame_filtros, width=12)
    e_fim.pack(side=LEFT)

    # Dashboard de indicadores
    frame_dash = Frame(janela_f, bg='#B6B6B6')
    frame_dash.pack(pady=8, padx=10, fill="x")

    def criar_card(parent, titulo):
        bg = '#BBD4F2'
        card = Frame(parent, bg=bg, bd=1, relief='flat', highlightthickness=0)
        card.pack(side=LEFT, padx=6, fill='x', expand=True)
        titulo_lbl = Label(card, text=titulo, bg=bg, fg='black', font=("Arial", 10, "bold"))
        titulo_lbl.pack(pady=(6,0))
        valor_lbl = Label(card, text="-", bg=bg, fg='black', font=("Arial", 16, "bold"))
        valor_lbl.pack(pady=(2,8))
        return valor_lbl

    lbl_lucro_pct = criar_card(frame_dash, "% de Lucro")
    lbl_qtd_vendas = criar_card(frame_dash, "Qtd. de Vendas (Saídas)")
    lbl_qtd_entradas = criar_card(frame_dash, "Qtd. de Entradas")

    # Caixa de texto para Lucro em R$
    frame_lucro_rs = Frame(janela_f, bg='#B6B6B6')
    frame_lucro_rs.pack(padx=10, fill='x')
    Label(frame_lucro_rs, text="Lucro (R$):", bg='#B6B6B6').pack(side=LEFT)
    lucro_entry = Entry(frame_lucro_rs)
    lucro_entry.pack(side=LEFT, padx=6, fill='x', expand=True)
    lucro_entry.configure(state='readonly')

    frame_tabela = Frame(janela_f, bg='#B6B6B6')
    frame_tabela.pack(pady=10, padx=10, fill="both", expand=True)

    colunas_r = ('Produto', 'Qtd Entrada', 'Qtd Saída', 'Estoque Atual', 'Total Compra (R$)', 'Total Venda (R$)', 'Lucro (R$)')
    tree_r = ttk.Treeview(frame_tabela, columns=colunas_r, show='headings')
    for c in colunas_r:
        tree_r.heading(c, text=c)
    for c, w in zip(colunas_r, [200, 90, 90, 110, 120, 120, 100]):
        tree_r.column(c, width=w, anchor=CENTER if c != 'Produto' else W)
    tree_r.pack(side="left", fill="both", expand=True)
    scrollbar_r = ttk.Scrollbar(frame_tabela, orient="vertical", command=tree_r.yview)
    tree_r.configure(yscrollcommand=scrollbar_r.set)
    scrollbar_r.pack(side="right", fill="y")

    def carregar():
        for i in tree_r.get_children():
            tree_r.delete(i)
        # Identifica produto escolhido
        prod_id_filtro = None
        sel = cb_produto.get()
        if sel:
            try:
                prod_id_filtro = int(sel.split(' - ')[0])
            except:
                prod_id_filtro = None

        dados = calcular_resumo_caixa(e_ini.get().strip() or None, e_fim.get().strip() or None, prod_id_filtro)
        total_compra_geral = 0
        total_venda_geral = 0
        soma_qtd_entradas = 0
        soma_qtd_saidas = 0
        for pid, nome, qtd_e, qtd_s, tot_c, tot_v in dados:
            qtd_e = qtd_e or 0
            qtd_s = qtd_s or 0
            tot_c = tot_c or 0
            tot_v = tot_v or 0
            soma_qtd_entradas += qtd_e
            soma_qtd_saidas += qtd_s
            conn = sqlite3.connect(DB_NAME)
            cur = conn.cursor()
            cur.execute("SELECT quantidade FROM produtos WHERE id=?", (pid,))
            estoque_atual = cur.fetchone()[0]
            conn.close()
            lucro = tot_v - tot_c
            total_compra_geral += tot_c
            total_venda_geral += tot_v
            tree_r.insert('', 'end', values=(nome, qtd_e, qtd_s, estoque_atual, f"{tot_c:.2f}", f"{tot_v:.2f}", f"{lucro:.2f}"))

        lucro_total = (total_venda_geral - total_compra_geral)
        lbl_totais.config(text=f"Total de Compras: R$ {total_compra_geral:.2f}    Total de Vendas: R$ {total_venda_geral:.2f}    Lucro: R$ {lucro_total:.2f}")
        margem = ((total_venda_geral - total_compra_geral) / total_venda_geral * 100) if total_venda_geral > 0 else 0
        lbl_lucro_pct.config(text=f"{margem:.1f}%")
        lbl_qtd_vendas.config(text=f"{soma_qtd_saidas:.0f}")
        lbl_qtd_entradas.config(text=f"{soma_qtd_entradas:.0f}")
        # Atualiza lucro em R$ na caixa de texto
        lucro_entry.configure(state='normal')
        lucro_entry.delete(0, END)
        lucro_entry.insert(0, f"{lucro_total:.2f}")
        lucro_entry.configure(state='readonly')

    Button(frame_filtros, text="Carregar", bg="#BBD4F2", fg="black", command=carregar).pack(side=LEFT, padx=10)

    lbl_totais = Label(janela_f, text="", bg='#B6B6B6', font=("Arial", 10, "bold"))
    lbl_totais.pack(pady=5)

# --- 4. Configuração da Janela Principal ---

setup_db()

root = Tk()
root.title("Gestão de Estoque - Barbearia DEMO")
root.geometry("1000x520")
root.configure(bg='#B6B6B6')

container = Frame(root, bg='#B6B6B6')
container.pack(pady=10, padx=10, fill="both", expand=True)

# Barra lateral à esquerda
sidebar = Frame(container, bg='#B6B6B6')
sidebar.pack(side="left", fill="y")

# Utilitário para criar tiles laterais estilo cartão com ícone e texto
def criar_tile(parent, titulo, icone_texto, on_click):
    tile_bg = '#BBD4F2'
    tile_bg_hover = '#A7C5EA'
    frame = Frame(parent, bg=tile_bg, bd=1, relief='flat', highlightthickness=0)
    frame.pack(pady=6, padx=2, anchor='w')
    # tamanho consistente
    frame.configure(width=180, height=80)
    frame.pack_propagate(False)

    icone = Label(frame, text=icone_texto, bg=tile_bg, fg='black', font=("Arial", 18, "bold"))
    icone.pack(pady=(8,0))
    titulo_lbl = Label(frame, text=titulo, bg=tile_bg, fg='black', font=("Arial", 10, "bold"))
    titulo_lbl.pack(pady=(2,8))

    def enter(_):
        frame.configure(bg=tile_bg_hover)
        icone.configure(bg=tile_bg_hover)
        titulo_lbl.configure(bg=tile_bg_hover)
    def leave(_):
        frame.configure(bg=tile_bg)
        icone.configure(bg=tile_bg)
        titulo_lbl.configure(bg=tile_bg)
    def click(_):
        if callable(on_click):
            on_click()
    for w in (frame, icone, titulo_lbl):
        w.bind('<Enter>', enter)
        w.bind('<Leave>', leave)
        w.bind('<Button-1>', click)
        w.configure(cursor='hand2')
    return frame

# Área central com tabela
frame_tabela = Frame(container, bg='#B6B6B6')
frame_tabela.pack(side="left", padx=10, fill="both", expand=True)

colunas = ('ID', 'Produto', 'Categoria', 'Qtd. Atual', 'Qtd. Mínima', 'Preço Custo', 'Preço Venda')
tree = ttk.Treeview(frame_tabela, columns=colunas, show='headings')

tree.column('ID', width=50, anchor=CENTER)
tree.column('Produto', width=250, anchor=W)
tree.column('Categoria', width=120, anchor=CENTER)
tree.column('Qtd. Atual', width=100, anchor=CENTER)
tree.column('Qtd. Mínima', width=100, anchor=CENTER)
tree.column('Preço Custo', width=100, anchor=CENTER)
tree.column('Preço Venda', width=100, anchor=CENTER)

for col in colunas:
    tree.heading(col, text=col)

# Estilo visual da Treeview e cabeçalhos
style = ttk.Style()
try:
    style.theme_use('default')
except:
    pass
style.configure('Treeview', background='#D0D0D0', fieldbackground='#D0D0D0', foreground='black')
style.map('Treeview', background=[('selected', '#9BBEEA')])
style.configure('Treeview.Heading', background='#BBD4F2', foreground='black')

# Tags para listras e alerta dentro da tree principal
tree.tag_configure('odd', background='#C9C9C9')
tree.tag_configure('even', background='#D9D9D9')
tree.tag_configure('alerta', background='#F2C9C9')

tree.pack(side="left", fill="both", expand=True)

scrollbar = ttk.Scrollbar(frame_tabela, orient="vertical", command=tree.yview)
tree.configure(yscrollcommand=scrollbar.set)
scrollbar.pack(side="right", fill="y")

Label(sidebar, text="Menu", bg='#B6B6B6', font=("Arial", 11, "bold")).pack(anchor='w', padx=2, pady=(0,4))

criar_tile(sidebar, "Novo Produto", "➕", abrir_janela_cadastro)
criar_tile(sidebar, "Entrada de Estoque", "⬆", lambda: abrir_janela_movimentacao("ENTRADA"))
criar_tile(sidebar, "Saída de Estoque", "⬇", lambda: abrir_janela_movimentacao("SAÍDA"))
criar_tile(sidebar, "Definir Preços", "💲", abrir_janela_precos)
criar_tile(sidebar, "Fechamento de Caixa", "🧾", lambda: abrir_janela_fechamento_caixa())

atualizar_listagem()

root.mainloop()